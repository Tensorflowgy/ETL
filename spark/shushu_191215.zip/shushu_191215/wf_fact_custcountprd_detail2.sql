----------------------------------------------------------------------
--  功能:WF_FACT_CUSTCOUNTPRD_DETAIL2                                  -- 
--  创建日期:                                                       --
--  创建人:                                                         --
--  修改记录                                                        --
--  ------------------------------------------------------------------
--  源表:fact_custcountprd_detail                                      -- 
--  目标表:fact_custcountprd_detail2                                   --
--  临时表:tmp_fact_custcountprd_detail2                               --
--  中间表:                                                         --
--  参数:                                                           --
----------------------------------------------------------------------
WITH tmp_custcountprd_detail AS
 (SELECT t.tano,
         t.customerid,
         --t.sk_agency,
         t.custtype,
		 t.sharetype,
		 t.bk_fundcode,
         t.onnullflag,
         t.oncloseflag,
         t.onopenflag,
         t.oneffectflag,
         t.onsleepflag,
         t.onloseflag,
         k.sk_date      AS effective_from,
         k.sk_date      AS effective_to
    FROM fact_custcountprd_detail t, comm_cldr_custom k
   WHERE t.effective_from <= k.sk_date
     AND t.effective_to >= k.sk_date
     AND k.sk_date = '&date'),
--1-开户（有一个开户）
tmp_onopenflag AS
 (SELECT customerid, custtype, sharetype, bk_fundcode, onopenflag
    FROM tmp_custcountprd_detail
   WHERE onopenflag = 1
   GROUP BY customerid, custtype, sharetype, bk_fundcode, onopenflag),
--2-销户（全部销户）
tmp_oncloseflag AS
 (SELECT t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.oncloseflag
    FROM tmp_custcountprd_detail t
   WHERE NOT EXISTS (SELECT 1
            FROM tmp_custcountprd_detail k
           WHERE k.customerid = t.customerid
             AND k.custtype = t.custtype
			 AND k.sharetype = t.sharetype
			 AND k.bk_fundcode=k.bk_fundcode
             AND k.oncloseflag = 0 )
     AND t.oncloseflag = 1
   GROUP BY t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.oncloseflag),
--3-有效（有一个有效）
tmp_oneffectflag AS
 (SELECT t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.oneffectflag
    FROM tmp_custcountprd_detail t
   WHERE t.oneffectflag = 1
   GROUP BY t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.oneffectflag),
--4-休眠（全部休眠）
tmp_onsleepflag AS
 (SELECT t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.onsleepflag
    FROM tmp_custcountprd_detail t
   WHERE NOT EXISTS (SELECT 1
            FROM tmp_custcountprd_detail k
           WHERE k.customerid = t.customerid
             AND k.custtype = t.custtype
			 AND k.sharetype = t.sharetype
			 AND k.bk_fundcode=k.bk_fundcode
             AND k.onsleepflag  = 0 )
     AND t.onsleepflag = 1
   GROUP BY t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.onsleepflag
  HAVING COUNT(1) = 1),
--5-流失（全部流失）
tmp_onloseflag AS
 (SELECT t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.onloseflag
    FROM tmp_custcountprd_detail t
   WHERE NOT EXISTS (SELECT 1
            FROM tmp_custcountprd_detail k
           WHERE k.customerid = t.customerid
             AND k.custtype = t.custtype
			 AND k.sharetype = t.sharetype
			 AND k.bk_fundcode=k.bk_fundcode
             AND k.onloseflag = 0 )
     AND t.onloseflag = 1
   GROUP BY t.customerid, t.custtype, t.sharetype, t.bk_fundcode, t.onloseflag
  HAVING COUNT(1) = 1)
--6-空户（汇总计算）
--7-汇总
INSERT overwrite TABLE az_dcdw.tmp_fact_custcountprd_detail2
SELECT --t1.tano,
       t1.customerid,
	   t1.bk_fundcode,
	   t1.sharetype,
       t1.custtype,
       CASE
         WHEN nvl(t2.onopenflag, 0) = 1 AND nvl(t4.oneffectflag, 0) <> 1 AND
              nvl(t6.onsleepflag, 0) <> 1 THEN
          1
         ELSE
          0
       END AS onnullflag,
       nvl(t2.onopenflag, 0) AS onopenflag,
       nvl(t3.oncloseflag, 0) AS oncloseflag,
       nvl(t4.oneffectflag, 0) AS oneffectflag,
       nvl(t5.onloseflag, 0) AS onloseflag,
       nvl(t6.onsleepflag, 0) AS onsleepflag,
       t1.effective_from,
       t1.effective_to
  FROM (SELECT t.tano,
               t.customerid,
               t.custtype,
			   t.sharetype,
			   t.bk_fundcode,
               t.effective_from,
               t.effective_to
          FROM tmp_custcountprd_detail t
         GROUP BY t.tano,
                  t.customerid,
                  t.custtype,
				  t.sharetype,
				  t.bk_fundcode,
                  t.effective_from,
                  t.effective_to) t1
  LEFT JOIN tmp_onopenflag t2
    ON t2.customerid = t1.customerid
   AND t2.custtype = t1.custtype
   AND t2.sharetype = t1.sharetype
   AND t2.bk_fundcode=t1.bk_fundcode
  LEFT JOIN tmp_oncloseflag t3
    ON t2.customerid = t1.customerid
   AND t2.custtype = t1.custtype
   AND t2.sharetype = t1.sharetype
   AND t2.bk_fundcode=t1.bk_fundcode
  LEFT JOIN tmp_oneffectflag t4
    ON t2.customerid = t1.customerid
   AND t2.custtype = t1.custtype
   AND t2.sharetype = t1.sharetype
   AND t2.bk_fundcode=t1.bk_fundcode
  LEFT JOIN tmp_onloseflag t5
    ON t2.customerid = t1.customerid
   AND t2.custtype = t1.custtype
   AND t2.sharetype = t1.sharetype
   AND t2.bk_fundcode=t1.bk_fundcode
  LEFT JOIN tmp_onsleepflag t6
    ON t2.customerid = t1.customerid
   AND t2.custtype = t1.custtype
   AND t2.sharetype = t1.sharetype
   AND t2.bk_fundcode=t1.bk_fundcode;

WITH tmp_custcountprd_detail_finnal AS
 (SELECT --a.tano,
         a.customerid,
		 a.bk_fundcode,
         --a.sk_agency,
         --a.agencyno,
		 a.sharetype,
         a.custtype,
         a.onnullflag     AS onnullflag,
         a.onopenflag     AS onopenflag,
         a.oncloseflag    AS oncloseflag,
         a.oneffectflag   AS oneffectflag,
         a.onloseflag     AS onloseflag,
         a.onsleepflag    AS onsleepflag,
         b.onnullflag     AS onnullflag_t,
         b.onopenflag     AS onopenflag_t,
         b.oncloseflag    AS oncloseflag_t,
         b.oneffectflag   AS oneffectflag_t,
         b.onloseflag     AS onloseflag_t,
         b.onsleepflag    AS onsleepflag_t,
         a.effective_from,
         b.effective_from AS effective_from_cur
    FROM az_dcdw.tmp_fact_custcountprd_detail2 a
    LEFT JOIN az_dcdw.fact_custcountprd_detail2 b
       --a.tano = b.tano
     ON a.customerid = b.customerid
        --AND a.agencyno = b.agencyno
     AND a.custtype = b.custtype
	 AND a.sharetype = b.sharetype
	 AND a.bk_fundcode = b.bk_fundcode
     AND b.effective_to = 99991231),

tmp_custcountprd_detail_finnal1 AS
 (SELECT --a.tano,
         a.customerid,
         --a.sk_agency,
         --a.agencyno,
		 a.bk_fundcode,
		 a.sharetype,
         a.custtype,
         a.onnullflag     AS onnullflag,
         a.onopenflag     AS onopenflag,
         a.oncloseflag    AS oncloseflag,
         a.oneffectflag   AS oneffectflag,
         a.onloseflag     AS onloseflag,
         a.onsleepflag    AS onsleepflag,
         b.onnullflag     AS onnullflag_t,
         b.onopenflag     AS onopenflag_t,
         b.oncloseflag    AS oncloseflag_t,
         b.oneffectflag   AS oneffectflag_t,
         b.onloseflag     AS onloseflag_t,
         b.onsleepflag    AS onsleepflag_t,
         a.effective_from,
         b.effective_from AS effective_from_cur
    FROM az_dcdw.fact_custcountprd_detail2 a
   INNER JOIN az_dcdw.tmp_fact_custcountprd_detail2 b
       --a.tano = b.tano
     ON a.customerid = b.customerid
        --AND a.agencyno = b.agencyno
     AND a.custtype = b.custtype
	 AND a.sharetype = b.sharetype
	 AND a.bk_fundcode = b.bk_fundcode
     AND a.effective_to = 99991231),

--完全新增、发生变化记录
tmp_custcountprd_detail_final_new AS
 (SELECT DISTINCT --t1.tano,
                  t1.customerid,
                  --t1.sk_agency,
                  --t1.agencyno,
				  t1.bk_fundcode,
				  t1.sharetype,
                  t1.custtype,
                  t1.onnullflag,
                  t1.oncloseflag,
                  t1.onopenflag,
                  t1.oneffectflag,
                  t1.onsleepflag,
                  t1.onloseflag,
                  t1.effective_from,
                  99991231 AS effective_to
    FROM tmp_custcountprd_detail_finnal t1
   WHERE isnull(t1.effective_from_cur)
      OR (t1.oneffectflag != t1.oneffectflag_t OR
          t1.onloseflag != t1.onloseflag_t OR
          t1.onsleepflag != t1.onsleepflag_t OR
          t1.onnullflag != t1.onnullflag_t OR
          t1.oncloseflag != t1.oncloseflag_t OR
          t1.onopenflag != t1.onopenflag_t)),

--变更、更新记录
tmp_custcountprd_detail_final_update AS
 (SELECT DISTINCT --t1.tano,
                  t1.customerid,
                  --t1.sk_agency,
                  --t1.agencyno,
				  t1.bk_fundcode,
				  t1.sharetype,
                  t1.custtype,
                  t1.onnullflag,
                  t1.oncloseflag,
                  t1.onopenflag,
                  t1.oneffectflag,
                  t1.onsleepflag,
                  t1.onloseflag,
                  t1.effective_from,
                  concat(date_format(date_add(int_to_date(t1.effective_from_cur),
                                              -1),
                                     'yyyy'),
                         date_format(date_add(int_to_date(t1.effective_from_cur),
                                              -1),
                                     'MM'),
                         date_format(date_add(int_to_date(t1.effective_from_cur),
                                              -1),
                                     'dd')) AS effective_to
    FROM tmp_custcountprd_detail_finnal1 t1
   WHERE isnotnull(t1.effective_from_cur)
     AND (t1.oneffectflag != t1.oneffectflag_t OR
          t1.onloseflag != t1.onloseflag_t OR
          t1.onsleepflag != t1.onsleepflag_t OR
          t1.onnullflag != t1.onnullflag_t OR
          t1.oncloseflag != t1.oncloseflag_t OR
          t1.onopenflag != t1.onopenflag_t)) 
		  
INSERT overwrite TABLE az_dcdw.fact_custcountprd_detail2
SELECT t1.customerid AS customerid,
       --t1.sk_agency AS sk_agency,
       --t1.agencyno AS agencyno,
       t1.bk_fundcode AS bk_fundcode,
       t1.sharetype AS sharetype,
       t1.custtype AS custtype,
       t1.onnullflag AS onnullflag,
       t1.onopenflag AS onopenflag,
       t1.oncloseflag AS oncloseflag,
       t1.oneffectflag AS oneffectflag,
       t1.onloseflag AS onloseflag,
       t1.onsleepflag AS onsleepflag,
       t1.effective_from AS effective_from,
       t1.effective_to AS effective_to,
       '${batchno}' AS batchno,
       NULL AS sk_audit,
       current_timestamp() AS inserttime,
       current_timestamp() AS updatetime
  FROM tmp_custcountprd_detail_final_new t1
UNION ALL
SELECT t1.customerid AS customerid,
       --t1.sk_agency AS sk_agency,
       --t1.agencyno AS agencyno,
       t1.bk_fundcode AS bk_fundcode,
       t1.sharetype AS sharetype,
       t1.custtype AS custtype,
       t1.onnullflag AS onnullflag,
       t1.onopenflag AS onopenflag,
       t1.oncloseflag AS oncloseflag,
       t1.oneffectflag AS oneffectflag,
       t1.onloseflag AS onloseflag,
       t1.onsleepflag AS onsleepflag,
       t1.effective_from AS effective_from,
       IF(t2.effective_to IS NULL, t1.effective_to, t2.effective_to) AS effective_to,
       '${batchno}' AS batchno,
       NULL AS sk_audit,
       t1.inserttime AS inserttime,
       current_timestamp() AS updatetime
  FROM az_dcdw.fact_custcountprd_detail2 t1
  LEFT JOIN tmp_custcountprd_detail_final_update t2
    ON t1.customerid = t2.customerid
   AND t1.bk_fundcode = t2.bk_fundcode
   AND t1.sharetype = t2.sharetype
   AND t1.custtype = t2.custtype;
---------------------------------------------------------------------
--  功能: WF_FACT_FUNDACCO_MANAGERFEE_TOTAL                       --
--  创建日期:2019-11-05                                            --
--  创建人:yxw                                                     --
--  修改记录                                                       --
--  -----------------------------------------------------------------
--  源表:                                                           --
--  目标表:                                                         --
--  临时表:                                                        --
--  中间表:                                                        --
--  参数:batchno                                                   --
--------------------------------------------------------------------- 

WITH SOURCE AS
(select distinct a.customerid
  , a.custtype
  , a.bk_fundcode
  , a.oneffectflag
  , a.onloseflag
  , a.onsleepflag
  , a.effective_from
from az_dcdw.fact_custcountprd_detail2 a
inner join az_dcdw.dim_product b 
on a.bk_fundcode = b.bk_fundcode
where a.effective_from between '${startdate}' and '${enddate}'
)

INSERT OVERWRITE TABLE AZ_DCDW.TMP_FACT_CUSTCOUNTINTERPRD_DT2
SELECT   T1.customerid
        ,T1.custtype
        ,T1.bk_fundcode
        ,T1.oneffectflag
        ,T1.onloseflag
        ,T1.onsleepflag
        ,T1.effective_from
FROM SOURCE T1;

WITH FACT_CUSTCOUNTINTERPRD_DETAIL2_T1 AS
(SELECT  T1.customerid
        ,T1.custtype
        ,T1.bk_fundcode
        ,T1.oneffectflag
        ,T1.onloseflag
        ,T1.onsleepflag
        ,T2.oneffectflag   as oneffectflag_t
        ,T2.onloseflag   as onloseflag_t
        ,T2.onsleepflag   as onsleepflag_t
        ,T1.effective_from
        ,t2.effective_from as effective_from_cur
FROM AZ_DCDW.TMP_FACT_CUSTCOUNTINTERPRD_DT2 T1
LEFT JOIN AZ_DCDW.FACT_CUSTCOUNTINTERPRD_DETAIL2 T2
ON  T1.customerid=T2.customerid
AND T1.BK_FUNDCODE=T2.BK_FUNDCODE
AND T2.EFFECTIVE_TO=99991231
),

FACT_CUSTCOUNTINTERPRD_DETAIL2_T2 AS
(SELECT  T1.customerid
        ,T1.custtype
        ,T1.bk_fundcode
        ,T1.oneffectflag
        ,T1.onloseflag
        ,T1.onsleepflag
        ,T2.oneffectflag   as oneffectflag_t
        ,T2.onloseflag   as onloseflag_t
        ,T2.onsleepflag   as onsleepflag_t
        ,T1.effective_from
        ,t2.effective_from as effective_from_cur
FROM AZ_DCDW.FACT_CUSTCOUNTINTERPRD_DETAIL2 T1
LEFT JOIN AZ_DCDW.TMP_FACT_CUSTCOUNTINTERPRD_DT2 T2
ON  T1.customerid=T2.customerid
AND T1.BK_FUNDCODE=T2.BK_FUNDCODE
AND T1.EFFECTIVE_TO=99991231
),

FACT_CUSTCOUNTINTERPRD_DETAIL2_NEW AS
(SELECT  T1.customerid
        ,T1.custtype        
        ,T1.bk_fundcode
        ,T1.oneffectflag
        ,T1.onloseflag
        ,T1.onsleepflag
        ,T1.effective_from
        ,99991231 AS EFFECTIVE_TO
FROM FACT_CUSTCOUNTINTERPRD_DETAIL2_T1 T1
WHERE isnull(T1.effective_from_cur)
or (T1.EFFECTIVE_FROM>T1.EFFECTIVE_FROM_CUR and not isnull(T1.EFFECTIVE_FROM_CUR) )
),

FACT_CUSTCOUNTINTERPRD_DETAIL2_UPDATE AS
(SELECT  T1.customerid
        ,T1.custtype
        ,T1.bk_fundcode
        ,T1.oneffectflag
        ,T1.onloseflag
        ,T1.onsleepflag
        ,T1.effective_from 
        ,DATE_FORMAT(DATE_ADD(INT_TO_DATE(T1.EFFECTIVE_FROM_CUR),-1),'yyyy')*10000 +
               DATE_FORMAT(DATE_ADD(INT_TO_DATE(T1.EFFECTIVE_FROM_CUR),-1),'mm')*100 +
               DATE_FORMAT(DATE_ADD(INT_TO_DATE(T1.EFFECTIVE_FROM_CUR),-1),'dd') AS EFFECTIVE_TO
FROM FACT_CUSTCOUNTINTERPRD_DETAIL2_T2 T1
WHERE isnotnull(T1.effective_from_cur) and (T1.ONEFFECTFLAG!=T1.ONEFFECTFLAG_T or T1.ONLOSEFLAG!=T1.ONLOSEFLAG_T or T1.ONSLEEPFLAG!=T1.ONSLEEPFLAG_T )
or(T1.effective_from<T1.effective_from_cur and not isnull(T1.EFFECTIVE_FROM_CUR))
)

INSERT OVERWRITE TABLE AZ_DCDW.FACT_CUSTCOUNTINTERPRD_DETAIL2
SELECT       T1.customerid
            ,T1.custtype
            ,T1.bk_fundcode
            ,T1.oneffectflag
            ,T1.onloseflag
            ,T1.onsleepflag
            ,T1.EFFECTIVE_FROM
            ,T1.EFFECTIVE_TO
            ,'${batchno}'                          AS BATCHNO
            ,NULL                                  AS SK_AUDIT
            ,CURRENT_TIMESTAMP()                   AS INSERTTIME
            ,CURRENT_TIMESTAMP()                   AS UPDATETIME
FROM FACT_CUSTCOUNTINTERPRD_DETAIL2_NEW T1
WHERE NOT EXISTS(SELECT 1 FROM  AZ_DCDW.FACT_CUSTCOUNTINTERPRD_DETAIL2 T2
                    WHERE T1.CUSTOMERID=T2.CUSTOMERID
                      AND T1.bk_fundcode=T2.bk_fundcode
                      AND T1.EFFECTIVE_FROM=T2.EFFECTIVE_FROM)
UNION all
SELECT       T1.customerid
            ,T1.custtype
            ,T1.bk_fundcode
            ,IF(ISNULL(T2.ONEFFECTFLAG),T1.ONEFFECTFLAG,T2.ONEFFECTFLAG) AS ONEFFECTFLAG
            ,IF(ISNULL(T2.ONLOSEFLAG),T1.ONLOSEFLAG,T2.ONLOSEFLAG) AS ONLOSEFLAG
            ,IF(ISNULL(T2.ONSLEEPFLAG),T1.ONSLEEPFLAG,T2.ONSLEEPFLAG) AS ONSLEEPFLAG
            ,T1.EFFECTIVE_FROM
            ,IF(ISNULL(T2.EFFECTIVE_TO),T1.EFFECTIVE_TO,T2.EFFECTIVE_TO) AS EFFECTIVE_TO
            ,'${batchno}'                          AS BATCHNO
            ,NULL                                  AS SK_AUDIT
            ,T1.INSERTTIME                         AS INSERTTIME
            ,CURRENT_TIMESTAMP()                   AS UPDATETIME
FROM  AZ_DCDW.FACT_CUSTCOUNTINTERPRD_DETAIL2 T1
LEFT JOIN FACT_CUSTCOUNTINTERPRD_DETAIL2_UPDATE T2
ON  T1.CUSTOMERID=T2.CUSTOMERID
AND T1.bk_fundcode=T2.bk_fundcode
AND T1.EFFECTIVE_FROM=T2.EFFECTIVE_FROM;
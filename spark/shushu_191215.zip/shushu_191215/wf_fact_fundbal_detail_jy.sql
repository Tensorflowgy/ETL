---------------------------------------------------------------------
--  功能:  m_fact_fundbal_detail_jy                                --
--  创建日期:2019-10-25                                            --
--  创建人:YXW                                                     --
--  修改记录                                                       --
--  -----------------------------------------------------------------
--  源表: DW.ODS.vw_tp_tsharecurrents                             --
--        DW.AZ_DCODS.ctl_parameters                              --
--        DW.AZ_DCDW.dim_fundaccount                              --
--        DW.AZ_DCDW.DIM_TRADEACCOUNT                             --
--        DW.AZ_DCDW.DIM_CUSTOMER                                 --
--        DW.AZ_DCDW.DIM_AGENCY                                   --
--        DW.AZ_DCDW.FACT_FUNDBAL_DETAIL_JY                       --
--  目标表:   FACT_FUNDBAL_DETAIL_JY                               --
--  临时表:                                                        --
--  中间表:                                                        --
--  参数:BATCHNO                                                   --
--------------------------------------------------------------------- 

WITH VW_TP_TSHARECURRENTS AS (
SELECT  D_CDATE
       ,C_CSERIALNO
       ,C_BUSINFLAG
       ,D_REQUESTDATE
       ,C_REQUESTNO
       ,C_CUSTNO
       ,C_FUNDACCO
       ,C_TRADEACCO
       ,C_FUNDCODE
       ,C_SHARETYPE
       ,C_AGENCYNO
       ,C_NETNO
       ,F_OCCURSHARES
       ,F_OCCURBALANCE
       ,F_LASTSHARES
       ,F_OCCURFREEZE
       ,F_LASTFREEZESHARE
       ,C_SUMMARY
       ,F_GAINBALANCE
       ,D_SHAREVALIDDATE
       ,C_BONUSTYPE
       ,C_CUSTTYPE
       ,C_SHARECLASS
       ,C_BOURSEFLAG
       ,C_OUTBUSINFLAG
  FROM ods.ssa_tp_tsharecurrents
UNION ALL
SELECT  D_CDATE
       ,C_CSERIALNO
       ,C_BUSINFLAG
       ,D_REQUESTDATE
       ,C_REQUESTNO
       ,C_CUSTNO
       ,C_FUNDACCO
       ,C_TRADEACCO
       ,C_FUNDCODE
       ,C_SHARETYPE
       ,C_AGENCYNO
       ,C_NETNO
       ,F_OCCURSHARES
       ,F_OCCURBALANCE
       ,F_LASTSHARES
       ,F_OCCURFREEZE
       ,F_LASTFREEZESHARE
       ,C_SUMMARY
       ,F_GAINBALANCE
       ,D_SHAREVALIDDATE
       ,C_BONUSTYPE
       ,C_CUSTTYPE
       ,C_SHARECLASS
       ,C_BOURSEFLAG
       ,C_OUTBUSINFLAG
  FROM ods.ssa_tp_tsharecurrents_his
),
TMP_FACT_FUNDBAL_DETAIL_JY AS 
(select t2.customerid      as CUSTOMERID
       ,t2.sk_fundaccount  as SK_FUNDACCOUNT
       ,t3.sk_tradeaccount as SK_TRADEACCOUNT
       ,t3.sk_agency       as SK_AGENCY
       ,t.C_FUNDCODE       as BK_FUNDCODE
       ,t.C_SHARETYPE      as SHARETYPE
       ,t.C_AGENCYNO       as AGENCYNO
       ,t.C_NETNO          as NETNO
       ,t.C_BONUSTYPE      as BONUSTYPE
       ,t.C_BUSINFLAG      as BUSINFLAG
       ,t.C_CSERIALNO      as CSERIALNO
       ,t.F_OCCURSHARES    as SHARE_CHANGE
       ,t.F_LASTSHARES     as SHARES
       ,t.F_OCCURFREEZE    as FROZENSHARE_CHANGE
       ,t.F_LASTFREEZESHARE as FROZENSHARE
       ,t.D_CDATE
       ,t.D_SHAREVALIDDATE
 from vw_tp_tsharecurrents t
  inner join AZ_DCODS.CTL_PARAMETERS t1 
   on 1=1 and t1.pscope = 'GLOBAL'
   and t1.pname = 'INNERFUNDACCO'
  inner join AZ_DCDW.DIM_FUNDACCOUNT t2
   on t1.pval_c = t2.bk_fundaccount
  and t.C_FUNDACCO = t2.bk_fundaccount
  left join AZ_DCDW.DIM_TRADEACCOUNT t3
   on t.C_FUNDACCO = t3.BK_FUNDACCOUNT
  and t.C_TRADEACCO = t3.BK_TRADEACCOUNT
  and t.C_AGENCYNO = t3.AGENCYNO
  and t.C_NETNO = t3.NETNO
  left join az_dcdw.DIM_CUSTOMER t4
   on t2.CUSTOMERID=t4.CUSTOMERID
),
LKP_SKAGENCY AS
(SELECT 
  SK_AGENCY_TOP_STAT as SK_AGENCY_TOP_STAT
 ,SK_AGENCY          as SK_AGENCY 
FROM AZ_DCDW.DIM_AGENCY ADDA
),
LKP_EXISTS AS
(SELECT CSERIALNO    as CSERIALNO 
   FROM AZ_DCDW.FACT_FUNDBAL_DETAIL_JY JY
),

EXPTRANS AS
(SELECT 
    TFFDJ.CUSTOMERID                   AS CUSTOMERID                                                                
   ,TFFDJ.SK_FUNDACCOUNT               AS SK_FUNDACCOUNT                                                            
   ,TFFDJ.SK_TRADEACCOUNT              AS SK_TRADEACCOUNT                                                           
   ,LS.SK_AGENCY                       AS SK_AGENCY                                                                 
   ,LS.SK_AGENCY_TOP_STAT              AS SK_AGENCY_TOP_STAT                                                        
   ,TFFDJ.BK_FUNDCODE                  AS BK_FUNDCODE                                                               
   ,TFFDJ.SHARETYPE                    AS SHARETYPE                                                                 
   ,TFFDJ.AGENCYNO                     AS AGENCYNO                                                                  
   ,TFFDJ.NETNO                        AS NETNO                                                                     
   ,TFFDJ.BONUSTYPE                    AS BONUSTYPE                                                                 
   ,TFFDJ.BUSINFLAG                    AS BUSINFLAG                                                                 
   ,TFFDJ.CSERIALNO                    AS CSERIALNO                                                                 
   ,TFFDJ.SHARE_CHANGE                 AS SHARE_CHANGE                                                              
   ,TFFDJ.SHARES                       AS SHARES                                                                    
   ,TFFDJ.FROZENSHARE_CHANGE           AS FROZENSHARE_CHANGE                                                        
   ,TFFDJ.FROZENSHARE                  AS FROZENSHARE
   ,TFFDJ.D_CDATE                      AS D_CDATE
   ,TFFDJ.D_SHAREVALIDDATE             AS D_SHAREVALIDDATE
   ,DATE_TO_INT(TFFDJ.D_CDATE)         AS EFFECTIVE_FROM                                                            
   ,IF( DATE_TO_INT(TFFDJ.D_SHAREVALIDDATE) = 20991231 ,99991231,DATE_TO_INT(TFFDJ.D_SHAREVALIDDATE))
                                       AS EFFECTIVE_TO       
   ,if(ISNOTNULL(LE.CSERIALNO),'Y','N')     AS existflag
FROM TMP_FACT_FUNDBAL_DETAIL_JY TFFDJ
LEFT JOIN LKP_SKAGENCY LS
ON LS.SK_AGENCY=TFFDJ.SK_AGENCY
LEFT JOIN LKP_EXISTS LE
ON LE.CSERIALNO=TFFDJ.CSERIALNO   
),

--取历史上一次记录
FACT_FUNDBAL_DETAIL_JY_LAST AS
(SELECT      SK_FUNDACCOUNT
            ,SK_TRADEACCOUNT
            ,BK_FUNDCODE
            ,SHARETYPE
            ,AGENCYNO
            ,NETNO
            ,SHARES
            ,MAX(EFFECTIVE_FROM) AS EFFECTIVE_FROM
FROM AZ_DCDW.FACT_FUNDBAL_DETAIL_JY T1
GROUP BY    SK_FUNDACCOUNT
        ,SK_TRADEACCOUNT
        ,BK_FUNDCODE
        ,SHARETYPE
        ,AGENCYNO
        ,NETNO
        ,SHARES
),

FUNDBAL_DETAIL_JY AS
(SELECT  T1.CUSTOMERID
        ,T1.SK_FUNDACCOUNT
        ,T1.SK_TRADEACCOUNT
        ,T1.SK_AGENCY
        ,T1.SK_AGENCY_TOP_STAT
        ,T1.BK_FUNDCODE
        ,T1.SHARETYPE
        ,T1.AGENCYNO
        ,T1.NETNO
        ,T1.BONUSTYPE
        ,T1.BUSINFLAG
        ,T1.CSERIALNO
        ,T1.SHARE_CHANGE
        ,T1.SHARES
        ,IF(ISNULL(T2.SHARES),0,T2.SHARES) AS LASTSHARES
        ,T1.FROZENSHARE_CHANGE
        ,T1.FROZENSHARE
        ,T1.EFFECTIVE_FROM
        ,T1.EFFECTIVE_TO
        ,T1.existflag
FROM  EXPTRANS T1
LEFT JOIN FACT_FUNDBAL_DETAIL_JY_LAST t2
ON   T1.SK_FUNDACCOUNT=T2.SK_FUNDACCOUNT
AND  T1.SK_TRADEACCOUNT=T2.SK_TRADEACCOUNT
AND  T1.BK_FUNDCODE=T2.BK_FUNDCODE
AND  T1.SHARETYPE=T2.SHARETYPE
AND  T1.AGENCYNO=T2.AGENCYNO
AND  T1.NETNO=T2.NETNO
)

INSERT OVERWRITE TABLE AZ_DCDW.FACT_FUNDBAL_DETAIL_JY
SELECT   '${tano}'              as tano
        ,T1.CUSTOMERID
        ,T1.SK_FUNDACCOUNT
        ,T1.SK_TRADEACCOUNT
        ,T1.SK_AGENCY
        ,T1.SK_AGENCY_TOP_STAT
        ,T1.BK_FUNDCODE
        ,T1.SHARETYPE
        ,T1.AGENCYNO
        ,T1.NETNO
        ,T1.BONUSTYPE
        ,T1.BUSINFLAG
        ,T1.CSERIALNO
        ,T1.SHARE_CHANGE
        ,T1.SHARES
        ,T1.LASTSHARES
        ,T1.FROZENSHARE_CHANGE
        ,T1.FROZENSHARE
        ,T1.EFFECTIVE_FROM
        ,T1.EFFECTIVE_TO
        ,'${srcsys}'                           AS SRCSYS
        ,'${batchno}'                          AS BATCHNO
        ,NULL                                  AS SK_AUDIT
        ,CURRENT_TIMESTAMP()                   AS INSERTTIME
        ,CURRENT_TIMESTAMP()                   AS UPDATETIME
FROM FUNDBAL_DETAIL_JY T1
WHERE existflag='N'
UNION ALL
SELECT  '${tano}'              as tano
        ,T1.CUSTOMERID
        ,T1.SK_FUNDACCOUNT
        ,T1.SK_TRADEACCOUNT
        ,T1.SK_AGENCY
        ,T1.SK_AGENCY_TOP_STAT
        ,T1.BK_FUNDCODE
        ,T1.SHARETYPE
        ,T1.AGENCYNO
        ,T1.NETNO
        ,T1.BONUSTYPE
        ,T1.BUSINFLAG
        ,T1.CSERIALNO
        ,T1.SHARE_CHANGE
        ,T1.SHARES
        ,IF(ISNULL(T2.LASTSHARES),0,T2.LASTSHARES) AS LASTSHARES
        ,T1.FROZENSHARE_CHANGE
        ,T1.FROZENSHARE
        ,T1.EFFECTIVE_FROM
        ,IF(ISNULL(T2.EFFECTIVE_TO),99991231,T2.EFFECTIVE_TO) AS EFFECTIVE_TO
        ,'${srcsys}'                           AS SRCSYS
        ,'${batchno}'                          AS BATCHNO
        ,NULL                                  AS SK_AUDIT
        ,CURRENT_TIMESTAMP()                   AS INSERTTIME
        ,CURRENT_TIMESTAMP()                   AS UPDATETIME
FROM  AZ_DCDW.FACT_FUNDBAL_DETAIL_JY T1
LEFT JOIN FUNDBAL_DETAIL_JY T2
ON   T1.SK_FUNDACCOUNT=T2.SK_FUNDACCOUNT
AND  T1.SK_TRADEACCOUNT=T2.SK_TRADEACCOUNT
AND  T1.BK_FUNDCODE=T2.BK_FUNDCODE
AND  T1.SHARETYPE=T2.SHARETYPE
AND  T1.AGENCYNO=T2.AGENCYNO
AND  T1.NETNO=T2.NETNO
AND  T2.existflag='Y'
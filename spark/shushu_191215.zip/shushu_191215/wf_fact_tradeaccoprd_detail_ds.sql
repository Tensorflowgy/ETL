---------------------------------------------------------------------
--  ����: FACT_TRADEACCO_DETAIL_DS                              --
--  ��������:                                                      --
--  ������:                                                        --
--  �޸ļ�¼                                                       --
--  -----------------------------------------------------------------
--  Դ��:fact_tradeaccochg_detail_ds                               --
--  Ŀ���:fact_tradeaccoprd_detail_ds                                                        --
--  ��ʱ��:                                                        --
--  �м��:                                                        --
--  ����: 
--  ͳ��ά�ȣ��ͻ�+���ۻ���+�����˺�+��Ʒ                                                      --
--------------------------------------------------------------------- 
WITH source AS
 (SELECT --t3.tano,
         t3.customerid,
         t3.sk_tradeaccount,
         t3.agencyno,
         t3.custtype,
         SUM(nvl(t3.shares, 0)) shares,
		 t3.bk_fundcode,
		 t3.sharetype
    FROM (SELECT --a.tano,
                 a.customerid,
                 a.sk_tradeaccount,
				 a.sk_capitalmode,
				 a.sk_bank,
                 a.agencyno,
                 a.custtype,
                 a.shares,
				 a.bk_fundcode,
				 a.sharetype
            FROM (SELECT --a.tano,
                         a.customerid,
                         --a.sk_fundaccount,
						 a.sk_tradeaccount,
				         nvl(c.sk_capitalmode,99999999) sk_capitalmode,
                         nvl(c.sk_bank,99999999) sk_bank,
                         a.agencyno,
                         a.custtype,
                         a.shares,
                         a.bk_fundcode,
						 a.sharetype
                         row_number() over(PARTITION BY a.customerid, a.sk_tradeaccount, a.agencyno, a.custtype, a.bk_fundcode, a.sharetype ORDER BY effective_from DESC) rn
                    FROM az_dcdw.fact_fundbal_detail a
				  INNER JOIN az_dcdw.dim_tradeaccount b 
				     ON b.sk_tradeaccount = a.sk_tradeaccount
                   WHERE a.effective_from <= '${startdate}'
                     AND a.effective_to > '${startdate}') a
           INNER JOIN az_dcdw.dim_product b
              ON a.bk_fundcode = b.bk_fundcode
             AND b.raisetype = '��ļ'
           WHERE a.rn = 1
          UNION ALL
          SELECT --a.tano,
                 a.customerid,
                 --a.sk_fundaccount,
				 a.sk_tradeaccount,
				 nvl(c.sk_capitalmode,99999999) sk_capitalmode,
                 nvl(c.sk_bank,99999999) sk_bank,
                 a.agencyno,
                 a.custtype,
                 a.shares,
				 a.bk_fundcode,
				 a.sharetype
            FROM az_dcdw.fact_money_fundbal_detail a
           INNER JOIN az_dcdw.dim_product b
              ON a.bk_fundcode = b.bk_fundcode
             AND b.raisetype = '��ļ'
		   INNER JOIN az_dcdw.dim_tradeaccount c 
		      ON c.sk_tradeaccount = a.sk_tradeaccount
           WHERE a.sk_date BETWEEN '${startdate}' AND '${enddate}') t3
   GROUP BY --t3.tano,
            t3.customerid,
            t3.sk_tradeaccount,
			t3.sk_capitalmode,
			t3.sk_bank,
            t3.agencyno,
            t3.custtype,
			t3.bk_fundcode,
		    t3.sharetype),
--״̬��ǩ����  ONEFFECTFLAG
v_oneffectflag AS
 (SELECT --a.tano,
         a.customerid,
         a.sk_tradeaccount,
		 a.sk_capitalmode,
		 a.sk_bank,
         a.agencyno,
         a.custtype,
		 a.bk_fundcode,
		 a.sharetype
         NULL AS onnullflag,
         NULL AS oncloseflag,
         NULL AS onopenflag,
         CASE
           WHEN a.shares THEN
            1
           ELSE
            0
         END AS oneffectflag,
         NULL AS onsleepflag,
         NULL AS onloseflag
    FROM SOURCE a),
--�������й��ķݶ�
tmp_shares_ago AS
 (SELECT --t3.tano,
         t3.customerid,
         t3.sk_tradeaccount,
		 t3.sk_capitalmode,
		 t3.sk_bank,
         t3.agencyno,
         t3.custtype,
         SUM(nvl(t3.shares, 0)) old_shares,
		 t3.bk_fundcode,
		 t3.sharetype
    FROM (SELECT DISTINCT --a.tano,
                          a.customerid,
                          a.sk_tradeaccount,
		                  c.sk_capitalmode,
		                  c.sk_bank,
                          a.agencyno,
                          a.custtype,
                          a.shares,
						  a.bk_fundcode,
		                  a.sharetype
            FROM az_dcdw.fact_fundbal_detail a
           INNER JOIN az_dcdw.dim_product b
              ON a.bk_fundcode = b.bk_fundcode
             AND b.raisetype = '��ļ'
		   INNER JOIN az_dcdw.dim_tradeaccount c 
		      ON c.sk_tradeaccount = a.sk_tradeaccount
           WHERE a.effective_from < '${startdate}'
          UNION ALL
          SELECT DISTINCT --a.tano,
                          a.customerid,
                          a.sk_tradeaccount,
		                  c.sk_capitalmode,
		                  c.sk_bank,
                          a.agencyno,
                          a.custtype,
                          a.shares,
						  a.bk_fundcode,
		                  a.sharetype
            FROM az_dcdw.fact_money_fundbal_detail a
           INNER JOIN az_dcdw.dim_product b
              ON a.bk_fundcode = b.bk_fundcode
             AND b.raisetype = '��ļ'
		   INNER JOIN az_dcdw.dim_tradeaccount c 
		      ON c.sk_tradeaccount = a.sk_tradeaccount
           WHERE a.sk_date < '${startdate}') t3
   GROUP BY --t3.tano,
            t3.customerid,
            t3.sk_tradeaccount,
		    t3.sk_capitalmode,
		    t3.sk_bank,
            t3.agencyno,
            t3.custtype,
			t3.bk_fundcode,
		    t3.sharetype),
--������־��������־
open_close AS
 (SELECT --a.tano,
         a.customerid,
         a.sk_tradeaccount,
		 a.sk_capitalmode,
		 a.sk_bank,
         a.agencyno,
         a.custtype,
         a.openflag,
         a.closeflag
    FROM (SELECT --a.tano,
                 a.customerid,
                 a.sk_tradeaccount,
				 a.sk_capitalmode,
				 a.sk_bank,
                 a.agencyno,
                 a.custtype,
                 a.openflag,
                 a.closeflag,
                 row_number() over(PARTITION BY a.customerid, a.sk_tradeaccount, a.sk_capitalmode, a.sk_bank, a.agencyno, a.custtype ORDER BY sk_date DESC) rn
            FROM az_dcdw.fact_tradeaccochg_detail_ds a
           WHERE sk_date <= '${startdate}') a
   WHERE rn = 1),

--״̬��ǩ����  ONLOSEFLAG
v_onloseflag AS
 (SELECT --t1.tano,
         t1.customerid,
         t1.sk_tradeaccount,
		 t1.sk_capitalmode,
		 t1.sk_bank,
         t1.agencyno,
         t1.custtype,
		 t1.bk_fundcode,
		 t1.sharetype
         NULL AS onnullflag,
         NULL AS oncloseflag,
         NULL AS onopenflag,
         NULL AS oneffectflag,
         NULL AS onsleepflag,
         CASE
           WHEN t1.old_shares > 0 AND t2.closeflag = 1 THEN
            1
           ELSE
            0
         END AS onloseflag
    FROM tmp_shares_ago t1
   INNER JOIN open_close t2
      ON t1.sk_tradeaccount = t2.sk_tradeaccount
	 AND t1.sk_capitalmode = t2.sk_capitalmode
	 AND t1.sk_bank = t2.sk_bank
	 -- t1.tano = t2.tano
     AND t1.customerid = t2.customerid
     --AND t1.sk_fundaccount = t2.sk_fundaccount
     AND t1.agencyno = t2.agencyno
     AND t1.custtype = t2.custtype),

--���߱�ǩ���� ONSLEEPFLAG
v_onsleepflag AS
 (SELECT --t1.tano,
         t1.customerid,
         --t1.sk_fundaccount,
		 t1.sk_tradeaccount,
		 t1.sk_capitalmode,
		 t1.sk_bank,
         t1.agencyno,
         t1.custtype,
		 t1.bk_fundcode,
		 t1.sharetype
         NULL AS onnullflag,
         NULL AS oncloseflag,
         NULL AS onopenflag,
         NULL AS oneffectflag,
         CASE
           WHEN t1.shares = 0 AND t2.old_shares > 0 AND t3.openflag = 1 THEN
            1
           ELSE
            0
         END AS onsleepflag,
         NULL AS onloseflag
    FROM SOURCE t1
   INNER JOIN tmp_shares_ago t2
      ON t1.sk_tradeaccount = t2.sk_tradeaccount
	 AND t1.sk_capitalmode = t2.sk_capitalmode
	 AND t1.sk_bank = t2.sk_bank
     AND t1.customerid = t2.customerid
     --AND t1.sk_fundaccount = t2.sk_fundaccount
     AND t1.agencyno = t2.agencyno
     AND t1.custtype = t2.custtype
	 AND t1.bk_fundcode = t2.bk_fundcode
	 AND t1.sharetype = t2.sharetype
   INNER JOIN open_close t3
      ON t1.sk_tradeaccount = t3.sk_tradeaccount
	 AND t1.sk_capitalmode = t3.sk_capitalmode
	 AND t1.sk_bank = t3.sk_bank
     AND t1.customerid = t3.customerid
     --AND t1.sk_fundaccount = t3.sk_fundaccount
     AND t1.agencyno = t3.agencyno
     AND t1.custtype = t3.custtype),

--δ����״̬��־������״̬��־
v_onopenflag_oncloseflag AS
 (SELECT --t3.tano,
         t3.customerid,
         t3.sk_tradeaccount,
		 t3.sk_capitalmode,
		 t3.sk_bank
         t3.agencyno,
         t3.custtype,
         NULL AS onnullflag,
         NULL AS oncloseflag,
         CASE
           WHEN t3.openflag = 1 THEN
            1
           ELSE
            0
         END AS onopenflag,
         CASE
           WHEN t3.closeflag = 1 THEN
            1
           ELSE
            0
         END AS oncloseflag,
         NULL AS onsleepflag,
         NULL AS onloseflag
    FROM open_close t3),

union_max AS
 (SELECT --t1.tano,
         t1.customerid,
         --t1.sk_fundaccount,
		 t1.sk_tradeaccount,
		 t1.sk_capitalmode,
		 t1.sk_bank,
         t1.agencyno,
         t1.custtype,
		 t1.bk_fundcode,
		 t1.sharetype,
         t1.oncloseflag,
         IF(t1.oncloseflag = 0, 1, t1.onopenflag) AS onopenflag,
         t1.oneffectflag,
         t1.onsleepflag,
         t1.onloseflag
    FROM (SELECT --t1.tano AS tano,
                 t1.customerid AS customerid,
                 --t1.sk_fundaccount AS sk_fundaccount,
				 t1.sk_tradeaccount AS sk_tradeaccount,
		         t1.sk_capitalmode AS sk_capitalmode,
		         t1.sk_bank  AS sk_bank
                 t1.agencyno AS agencyno,
                 t1.custtype AS custtype,
				 t1.bk_fundcode AS bk_fundcode,
		         t1.sharetype   AS sharetype,
                 nvl(MAX(t1.oncloseflag), 0) AS oncloseflag,
                 nvl(MAX(t1.onopenflag), 0) AS onopenflag,
                 nvl(MAX(t1.oneffectflag), 0) AS oneffectflag,
                 nvl(MAX(t1.onsleepflag), 0) AS onsleepflag,
                 nvl(MAX(t1.onloseflag), 0) AS onloseflag
            FROM (SELECT --t.tano           AS tano,
                         t.customerid     AS customerid,
                         --t.sk_fundaccount AS sk_fundaccount,
						 t.sk_tradeaccount AS sk_tradeaccount,
		                 t.sk_capitalmode AS sk_capitalmode,
		                 t.sk_bank        AS sk_bank,
						 t.bk_fundcode    AS bk_fundcode,
		                 t.sharetype      AS sharetype,
                         t.agencyno       AS agencyno,
                         t.custtype       AS custtype,
                         t.oncloseflag    AS oncloseflag,
                         t.onopenflag     AS onopenflag,
                         t.oneffectflag   AS oneffectflag,
                         t.onsleepflag    AS onsleepflag,
                         t.onloseflag     AS onloseflag
                    FROM v_oneffectflag t
                  UNION ALL
                  SELECT --t.tano           AS tano,
                         t.customerid     AS customerid,
                         --t.sk_fundaccount AS sk_fundaccount,
						 t.sk_tradeaccount AS sk_tradeaccount,
		                 t.sk_capitalmode AS sk_capitalmode,
		                 t.sk_bank        AS sk_bank,
						 t.bk_fundcode    AS bk_fundcode,
		                 t.sharetype      AS sharetype,
                         t.agencyno       AS agencyno,
                         t.custtype       AS custtype,
                         t.oncloseflag    AS oncloseflag,
                         t.onopenflag     AS onopenflag,
                         t.oneffectflag   AS oneffectflag,
                         t.onsleepflag    AS onsleepflag,
                         t.onloseflag     AS onloseflag
                    FROM v_onloseflag t
                  UNION ALL
                  SELECT --t.tano           AS tano,
                         t.customerid     AS customerid,
                         --t.sk_fundaccount AS sk_fundaccount,
						 t.sk_tradeaccount AS sk_tradeaccount,
		                 t.sk_capitalmode AS sk_capitalmode,
		                 t.sk_bank        AS sk_bank,
						 t.bk_fundcode    AS bk_fundcode,
		                 t.sharetype      AS sharetype,
                         t.agencyno       AS agencyno,
                         t.custtype       AS custtype,
                         t.oncloseflag    AS oncloseflag,
                         t.onopenflag     AS onopenflag,
                         t.oneffectflag   AS oneffectflag,
                         t.onsleepflag    AS onsleepflag,
                         t.onloseflag     AS onloseflag
                    FROM v_onsleepflag t
                  UNION ALL
                  SELECT --t.tano           AS tano,
                         t.customerid     AS customerid,
                         --t.sk_fundaccount AS sk_fundaccount,
						 t.sk_tradeaccount AS sk_tradeaccount,
		                 t.sk_capitalmode AS sk_capitalmode,
		                 t.sk_bank        AS sk_bank,
						 t.bk_fundcode    AS bk_fundcode,
		                 t.sharetype      AS sharetype,
                         t.agencyno       AS agencyno,
                         t.custtype       AS custtype,
                         t.oncloseflag    AS oncloseflag,
                         t.onopenflag     AS onopenflag,
                         t.oneffectflag   AS oneffectflag,
                         t.onsleepflag    AS onsleepflag,
                         t.onloseflag     AS onloseflag
                    FROM v_onopenflag_oncloseflag t) t1
           GROUP BY --t1.tano,
                    t1.customerid,
                    --t1.sk_fundaccount,
					t1.sk_tradeaccount,
					t1.sk_capitalmode,
					t1.sk_bank
                    t1.agencyno,
                    t1.custtype,
					t1.bk_fundcode,
		            t1.sharetype) t1),
null_final AS
 (SELECT --t1.tano           AS tano,
         t1.customerid     AS customerid,
         --t1.sk_fundaccount AS sk_fundaccount,
		 t1.sk_tradeaccount AS sk_tradeaccount,
		 t1.sk_capitalmode AS sk_capitalmode,
		 t1.sk_bank        AS sk_bank
         t1.agencyno       AS agencyno,
         t1.custtype       AS custtype,
		 t1.bk_fundcode    AS bk_fundcode,
		 t1.sharetype      AS sharetype,
         CASE WHEN nvl(t1.onopenflag, 0) = 1 AND nvl(t1.oneffectflag, 0) <> 1 AND nvl(t1.onsleepflag, 0) <> 1 THEN 1 ELSE 0 END AS onnullflag,
         t1.oncloseflag    AS oncloseflag,
         t1.onopenflag     AS onopenflag,
         t1.oneffectflag   AS oneffectflag,
         t1.onsleepflag    AS onsleepflag,
         t1.onloseflag     AS onloseflag
    FROM union_max t1)
INSERT overwrite TABLE az_dcdw.tmp_fact_tradeaccoprd_detail_ds --�˱�������Ҫ�½�
SELECT --t1.tano AS tano,
       t1.customerid AS customerid,
       --t1.sk_fundaccount AS sk_fundaccount,
	   t1.sk_tradeaccount AS sk_tradeaccount,
	   t1.sk_capitalmode AS sk_capitalmode,
	   t1.sk_bank        AS sk_bank
       mplt_skagency_top.sk_agency AS sk_agency,
       t1.agencyno AS agencyno,
       t1.custtype AS custtype,
	   t1.bk_fundcode AS bk_fundcode,
	   t1.sharetype AS sharetype,
       t1.onnullflag AS onnullflag,
       t1.oncloseflag AS oncloseflag,
       t1.onopenflag AS onopenflag,
       t1.oneffectflag AS oneffectflag,
       t1.onsleepflag AS onsleepflag,
       t1.onloseflag AS onloseflag,
       '${startdate}' AS effective_from
  FROM null_final t1
  LEFT JOIN (SELECT da.sk_agency AS sk_agency, da.agencyno AS agencyno
               FROM az_dcdw.dim_agency da
              WHERE agencylevel = 1) mplt_skagency_top
    ON t1.agencyno = mplt_skagency_top.agencyno;


WITH tmp_tradeaccoprd_detail_ds_finnal AS
 (SELECT --a.tano,
         a.customerid,
         --a.sk_fundaccount,
		 a.sk_tradeaccount,
		 a.sk_capitalmode,
		 a.sk_bank,
         a.sk_agency,
         a.agencyno,
         a.custtype,
		 a.bk_fundcode,
		 a.sharetype,
         a.onnullflag     AS onnullflag,
         a.onopenflag     AS onopenflag,
         a.oncloseflag    AS oncloseflag,
         a.oneffectflag   AS oneffectflag,
         a.onloseflag     AS onloseflag,
         a.onsleepflag    AS onsleepflag,
         b.onnullflag     AS onnullflag_t,
         b.onopenflag     AS onopenflag_t,
         b.oncloseflag    AS oncloseflag_t,
         b.oneffectflag   AS oneffectflag_t,
         b.onloseflag     AS onloseflag_t,
         b.onsleepflag    AS onsleepflag_t,
         a.effective_from,
         b.effective_from AS effective_from_cur
    FROM az_dcdw.tmp_fact_tradeaccoprd_detail_ds a
    LEFT JOIN az_dcdw.fact_tradeaccoprd_detail_ds b
      ON a.sk_tradeaccount = b.sk_tradeaccount
	 AND a.sk_capitalmode = b.sk_capitalmode
	 AND a.sk_bank = b.sk_bank
	 -- a.tano = b.tano
     AND a.customerid = b.customerid
     --AND a.sk_fundaccount = b.sk_fundaccount
     AND a.agencyno = b.agencyno
     AND a.custtype = b.custtype
     AND b.effective_to = 99991231
	 AND a.bk_fundcode = b.bk_fundcode
	 AND a.sharetype = b.sharetype),

tmp_tradeaccoprd_detail_ds_finnal1 AS
 (SELECT --a.tano,
         a.customerid,
         a.sk_tradeaccount,
         a.sk_agency,
         a.agencyno,
         a.custtype,
		 a.bk_fundcode,
		 a.sharetype,
         a.onnullflag     AS onnullflag,
         a.onopenflag     AS onopenflag,
         a.oncloseflag    AS oncloseflag,
         a.oneffectflag   AS oneffectflag,
         a.onloseflag     AS onloseflag,
         a.onsleepflag    AS onsleepflag,
         b.onnullflag     AS onnullflag_t,
         b.onopenflag     AS onopenflag_t,
         b.oncloseflag    AS oncloseflag_t,
         b.oneffectflag   AS oneffectflag_t,
         b.onloseflag     AS onloseflag_t,
         b.onsleepflag    AS onsleepflag_t,
         a.effective_from,
         b.effective_from AS effective_from_cur
    FROM az_dcdw.fact_tradeaccoprd_detail_ds a
   INNER JOIN az_dcdw.tmp_fact_tradeaccoprd_detail_ds b
      ON ON a.sk_tradeaccount = b.sk_tradeaccount
	 AND a.sk_capitalmode = b.sk_capitalmode
	 AND a.sk_bank = b.sk_bank
	 --  a.tano = b.tano
     AND a.customerid = b.customerid
     --AND a.sk_fundaccount = b.sk_fundaccount
     AND a.agencyno = b.agencyno
     AND a.custtype = b.custtype
     AND a.effective_to = 99991231
	 AND a.bk_fundcode = b.bk_fundcode
	 AND a.sharetype = b.sharetype),

--��ȫ�����������仯��¼
tmp_tradeaccoprd_detail_ds_final_new AS
 (SELECT DISTINCT --t1.tano,
                  t1.customerid,
                  --t1.sk_fundaccount,
				  t1.sk_tradeaccount,
				  t1.sk_capitalmode,
				  t1.sk_bank,
                  t1.sk_agency,
                  t1.agencyno,
                  t1.custtype,
				  t1.bk_fundcode,
				  t1.sharetype,
                  t1.onnullflag,
                  t1.oncloseflag,
                  t1.onopenflag,
                  t1.oneffectflag,
                  t1.onsleepflag,
                  t1.onloseflag,
                  t1.effective_from,
                  99991231 AS effective_to
    FROM tmp_tradeaccoprd_detail_ds_finnal t1
   WHERE isnull(t1.effective_from_cur)
      OR (t1.oneffectflag != t1.oneffectflag_t OR
          t1.onloseflag != t1.onloseflag_t OR
          t1.onsleepflag != t1.onsleepflag_t OR
          t1.onnullflag != t1.onnullflag_t OR
          t1.oncloseflag != t1.oncloseflag_t OR
          t1.onopenflag != t1.onopenflag_t)),

--��������¼�¼
tmp_tradeaccoprd_detail_ds_final_update AS
(SELECT DISTINCT --t1.tano,
                t1.customerid,
                --t1.sk_fundaccount,
				t1.sk_tradeaccount,
				t1.sk_capitalmode,
				t1.sk_bank,
                t1.sk_agency,
                t1.agencyno,
                t1.custtype,
				t1.bk_fundcode,
				t1.sharetype,
                t1.onnullflag,
                t1.oncloseflag,
                t1.onopenflag,
                t1.oneffectflag,
                t1.onsleepflag,
                t1.onloseflag,
                t1.effective_from,
                concat(date_format(date_add(int_to_date(t1.effective_from_cur),
                                            -1),
                                   'yyyy'),
                       date_format(date_add(int_to_date(t1.effective_from_cur),
                                            -1),
                                   'MM'),
                       date_format(date_add(int_to_date(t1.effective_from_cur),
                                            -1),
                                   'dd')) AS effective_to
  FROM tmp_tradeaccoprd_detail_ds_finnal1 t1
 WHERE isnotnull(t1.effective_from_cur)
   AND (t1.oneffectflag != t1.oneffectflag_t OR
        t1.onloseflag != t1.onloseflag_t OR
        t1.onsleepflag != t1.onsleepflag_t OR
        t1.onnullflag != t1.onnullflag_t OR
        t1.oncloseflag != t1.oncloseflag_t OR
        t1.onopenflag != t1.onopenflag_t)
)
INSERT overwrite TABLE az_dcdw.fact_tradeaccoprd_detail_ds
  SELECT t1.customerid AS customerid,
         t1.sk_tradeaccount AS sk_tradeaccount,
         t1.sk_agency AS sk_agency,
         t1.agencyno AS agencyno,
         t1.custtype AS custtype,
		 t1.sk_bank AS sk_bank,
		 t1.sk_capitalmode AS sk_capitalmode,
		 t1.bk_fundcode AS bk_fundcode,
		 t1.sharetype AS sharetype,
         t1.onnullflag AS onnullflag,
         t1.oncloseflag AS oncloseflag,
         t1.onopenflag AS onopenflag,
         t1.oneffectflag AS oneffectflag,
         t1.onsleepflag AS onsleepflag,
         t1.onloseflag AS onloseflag,
         t1.effective_from AS effective_from,
         t1.effective_to AS effective_to,
         '${batchno}' AS batchno,
         NULL AS sk_audit,
         current_timestamp() AS inserttime,
         current_timestamp() AS updatetime
    FROM tmp_tradeaccoprd_detail_ds_final_new t1
  UNION ALL
  SELECT --t1.tano AS tano,
         t1.customerid AS customerid,
         t1.sk_tradeaccount AS sk_tradeaccount,
         t1.sk_agency AS sk_agency,
         t1.agencyno AS agencyno,
         t1.custtype AS custtype,
		 t1.sk_bank AS sk_bank,
		 t1.sk_capitalmode AS sk_capitalmode,
		 t1.bk_fundcode AS bk_fundcode,
		 t1.sharetype AS sharetype,
         t1.onnullflag AS onnullflag,
         t1.oncloseflag AS oncloseflag,
         t1.onopenflag AS onopenflag,
         t1.oneffectflag AS oneffectflag,
         t1.onsleepflag AS onsleepflag,
         t1.onloseflag AS onloseflag,
         t1.effective_from AS effective_from,
         IF(t2.effective_to IS NULL, t1.effective_to, t2.effective_to) AS effective_to,
         '${batchno}' AS batchno,
         NULL AS sk_audit,
         t1.inserttime AS inserttime,
         current_timestamp() AS updatetime
    FROM az_dcdw.fact_tradeaccoprd_detail_ds t1
    LEFT JOIN tmp_tradeaccoprd_detail_ds_final_update t2
      ON t1.sk_tradeaccount = t2.sk_tradeaccount
	 AND t1.sk_bank = t2.sk_bank
	 AND t1.sk_capitalmode = t2.sk_capitalmode
	 -- t1.tano = t2.tano
     -- AND t1.sk_fundaccount = t2.sk_fundaccount
     AND t1.agencyno = t2.agencyno
	 AND t1.bk_fundcode = t2.bk_fundcode
	 AND t1.sharetype = t2.sharetype;
